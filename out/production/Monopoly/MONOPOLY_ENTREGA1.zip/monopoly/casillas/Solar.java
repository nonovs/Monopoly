package monopoly.casillas;

import monopoly.Grupo;
import partida.Jugador;

public class Solar extends Casilla {

    // Base
    private float alquilerBase;

    // Estado de edificaciones
    private int casas;          // 0..4
    private boolean hotel;      // true si hay hotel
    private boolean piscina;    // true si hay piscina
    private boolean pistaDeporte; // true si hay pista
    private float precioCasa;
    private float precioHotel;
    private float precioPiscina;
    private float precioPista;
    private float alquilerCasa;
    private float alquilerHotel;
    private float alquilerPiscina;
    private float alquilerPista;



    public Solar(
            String nombre, int posicion,
            int valor, float hipoteca, float alquilerBase,
            float precioCasa, float precioHotel, float precioPiscina, float precioPista,
            float alquilerCasa, float alquilerHotel, float alquilerPiscina, float alquilerPista,
            Jugador duenho, Grupo grupo
    ) {
        super(nombre, "Solar", posicion, valor, duenho);// Llama al constructor de Casilla,
        // this.setHipoteca(hipoteca);
        this.alquilerBase = alquilerBase;
        this.setGrupo(grupo);

        this.precioCasa = precioCasa;
        this.precioHotel = precioHotel;
        this.precioPiscina = precioPiscina;
        this.precioPista = precioPista;

        this.alquilerCasa = alquilerCasa;
        this.alquilerHotel = alquilerHotel;
        this.alquilerPiscina = alquilerPiscina;
        this.alquilerPista = alquilerPista;

        this.casas = 0;
        this.hotel = false;
        this.piscina = false;
        this.pistaDeporte = false;
    }


    @Override
    public boolean evaluarCasilla(Jugador actual, Jugador banca, int tirada) {
        if (getDuenho() == null || getDuenho() == actual || getDuenho() == banca)
            return true;

        float alquiler = calcularAlquiler();
        if (actual.getFortuna() >= alquiler) {
            actual.pagar(alquiler);
            getDuenho().recibir(alquiler);
            return true;
        } else {
            System.out.println(actual.getNombre() + " no puede pagar el alquiler de " + alquiler);
            return false;
        }
    }

    @Override
    public void comprarCasilla(Jugador solicitante, Jugador banca) {
        if (getDuenho() != banca) {
            System.out.println("Este solar ya tiene dueño.");
            return;
        }
        if (solicitante.getPosicion() != this.getPosicion()) {
            System.out.println("Solo puedes comprar la casilla en la que estás situado.");
            return;
        }
        if (solicitante.getFortuna() < getValor()) {
            System.out.println(solicitante.getNombre() + " no tiene suficiente dinero para comprar " + getNombre());
            return;
        }
        solicitante.pagar(getValor());
        setDuenho(solicitante);
        solicitante.anhadirPropiedad(this);

        System.out.printf(
                "El jugador %s compra la casilla %s por %.0f€. Su fortuna actual es %.0f€.\n",
                solicitante.getNombre(), getNombre(), getValor(), solicitante.getFortuna()
        );
    }

    public float calcularAlquiler() {
        float total = alquilerBase;

        if (casas > 0) total += casas * alquilerCasa;
        if (hotel)     total += alquilerHotel;
        if (piscina)   total += alquilerPiscina;
        if (pistaDeporte) total += alquilerPista;

        Grupo g = getGrupo();
        if (g != null && g.esDuenhoGrupo(getDuenho()) && casas == 0 && !hotel && !piscina && !pistaDeporte) {
            total *= 2;
        }
        return total;
    }


    public boolean construirCasa() {
        Grupo g = getGrupo();
        if (g != null && casas < 4 && !hotel && g.esDuenhoGrupo(getDuenho())) {
            casas++;
            return true;
        }
        return false;
    }

    public boolean construirHotel() {
        if (casas == 4 && !hotel) {
            casas = 0;
            hotel = true;
            return true;
        }
        return false;
    }

    public boolean construirPiscina() {
        if (hotel && !piscina) {
            piscina = true;
            return true;
        }
        return false;
    }

    public boolean construirPista() {
        if (hotel && piscina && !pistaDeporte) {
            pistaDeporte = true;
            return true;
        }
        return false;
    }


    @Override
    public String infoCasilla() {
        String color = (getGrupo() != null && getGrupo().getColor() != null) ? getGrupo().getColor() : "N/A";
        String duenhoStr = (getDuenho() != null) ? getDuenho().getNombre() : "banca";

        return String.format(
            "{%n" +
            " tipo: Solar,%n" +
            " grupo: %s,%n" +
            " propietario: %s,%n" +
            " valor: %.0f,%n" +
            " hipoteca: %.0f,%n" +
            " alquiler base: %.0f,%n" +
            " precio casa: %.0f,%n" +
            " precio hotel: %.0f,%n" +
            " precio piscina: %.0f,%n" +
            " precio pista: %.0f,%n" +
            " alquiler casa: %.0f,%n" +
            " alquiler hotel: %.0f,%n" +
            " alquiler piscina: %.0f,%n" +
            " alquiler pista: %.0f%n" +
            "}",
            color, duenhoStr,
            getValor(), getHipoteca(), alquilerBase,
            precioCasa, precioHotel, precioPiscina, precioPista,
            alquilerCasa, alquilerHotel, alquilerPiscina, alquilerPista
        );
    }

    @Override
    public String casEnVenta() {
        if (getDuenho() != null && !"Banca".equalsIgnoreCase(getDuenho().getNombre())) {
            return "";
        }
        return String.format("{%n  tipo: solar,%n  grupo: %s,%n  valor: %.0f%n}", getGrupo(), getValor());
    }

    public float getAlquilerBase() { return alquilerBase; }

    public float getPrecioCasa() { return precioCasa; }
    public float getPrecioHotel() { return precioHotel; }
    public float getPrecioPiscina() { return precioPiscina; }
    public float getPrecioPista() { return precioPista; }

    public float getAlquilerCasa() { return alquilerCasa; }
    public float getAlquilerHotel() { return alquilerHotel; }
    public float getAlquilerPiscina() { return alquilerPiscina; }
    public float getAlquilerPista() { return alquilerPista; }

    public int getCasas() { return casas; }
    public boolean hasHotel() { return hotel; }
    public boolean hasPiscina() { return piscina; }
    public boolean hasPistaDeporte() { return pistaDeporte; }

    public void setPreciosMejoras(float precioCasa, float precioHotel, float precioPiscina, float precioPista) {
        this.precioCasa = precioCasa;
        this.precioHotel = precioHotel;
        this.precioPiscina = precioPiscina;
        this.precioPista = precioPista;
    }

    public void setAlquileresMejoras(float alquilerCasa, float alquilerHotel, float alquilerPiscina, float alquilerPista) {
        this.alquilerCasa = alquilerCasa;
        this.alquilerHotel = alquilerHotel;
        this.alquilerPiscina = alquilerPiscina;
        this.alquilerPista = alquilerPista;
    }
}
